Personal CV Webpage Project

- Created by: Shaikhah Salman
- Email: Smshaikhah@gmail.com
- Project: Personal CV Web Page using HTML

This project includes:
- index.html : Main CV web page

Thank you!
